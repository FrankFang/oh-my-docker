Usage:

    rvm group help
    rvm group add <group_name> <user_name> [user_name...]
    rvm group create <group_name> [group_id]
